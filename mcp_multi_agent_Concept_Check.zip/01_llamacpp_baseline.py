import os
from llama_cpp import Llama
from langchain_community.llms import LlamaCpp

# UPDATE THIS TO YOUR LOCAL DOWNLOAD PATH
MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"

print("--- 1. DIRECT LLAMA.CPP INFERENCE ---")
# Direct execution invokes the bare C++ binding context
raw_llm = Llama(model_path=MODEL_PATH, n_ctx=512, verbose=False)
raw_output = raw_llm("Q: What is 2+2? A: ", max_tokens=10)
print(f"Direct Output: {raw_output['choices'][0]['text'].strip()}\n")


print("--- 2. LANGCHAIN WRAPPER INFERENCE ---")
# The LangChain wrapper abstracts the model into a common Runnable interface (.invoke)
lc_llm = LlamaCpp(
    model_path=MODEL_PATH,
    n_ctx=512,
    temperature=0.1,
    verbose=False
)
wrapped_output = lc_llm.invoke("What is the capital of France?")
print(f"Wrapper Output: {wrapped_output.strip()}")