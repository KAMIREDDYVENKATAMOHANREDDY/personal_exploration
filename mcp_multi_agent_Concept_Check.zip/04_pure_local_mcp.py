# 04_pure_local_mcp.py
import asyncio
from mcp.server.fastmcp import FastMCP
from langchain_mcp_adapters.tools import load_mcp_tools
from langchain_community.llms import LlamaCpp
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# 1. Initialize local GGUF engine
MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=1024, verbose=False)

async def main():
    # 2. Define the exact command that spins up our background tool server process.
    # This simulates exactly what Claude Desktop does under the hood, using pure Python.
    server_params = StdioServerParameters(
        command="python",
        args=["-c", """
from mcp.server.fastmcp import FastMCP
mcp = FastMCP("SystemMetricsServer")

@mcp.tool()
def get_server_load(active_connections: int) -> str:
    \"\"\"Calculate system burden metrics based on connection strings.\"\"\"
    calc = float(active_connections) * 1.42
    return f"Calculated burden state: {calc:.2f}% utilization."

if __name__ == '__main__':
    mcp.run(transport='stdio')
"""]
    )

    print("Connecting directly to local MCP engine using standard IO sub-processes...")
    
    # 3. Establish the local client session link
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # Complete the MCP handshake protocol
            await session.initialize()
            
            # 4. Discover and translate MCP Server tools to native LangChain tools
            discovered_tools = await load_mcp_tools(session)
            print(f"\n[MCP Discovery] Found Server Tool: {discovered_tools[0].name}")
            print(f"[MCP Discovery] Description: {discovered_tools[0].description}")
            
            # 5. Direct Execution Test (No UI, No Claude, Pure local Python)
            print("\nExecuting tool locally using adapter logic...")
            execution_payload = {"active_connections": 45}
            result = await discovered_tools[0].ainvoke(execution_payload)
            
            print(f"\n[Tool Result]: {result}")

if __name__ == "__main__":
    asyncio.run(main())