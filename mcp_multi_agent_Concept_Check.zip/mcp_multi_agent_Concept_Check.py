# mcp_multi_agent_fixed.py
import os
import re
import requests
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP
from langchain_community.llms import LlamaCpp

# 1. FIX 1: Add 'r' before path string to kill all Windows Syntax Warnings
MODEL_PATH = r"D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=2048, verbose=False)

mcp_hub = FastMCP("InHouseEnterpriseHubFixed")
LOG_FILE = "agent_system_logs.txt"

# --- TOOL 1: MATH EXPERT SYSTEM (FIXED REGEX PARSING) ---
@mcp_hub.tool()
def compute_math_operation(operation_type: str, num1: float, num2: float) -> str:
    """Perform direct calculations like sum, subtract, multiply, or divide."""
    if operation_type == "sum":
        return f"Calculation Result: {num1} + {num2} = {num1 + num2}"
    elif operation_type == "multiply":
        return f"Calculation Result: {num1} * {num2} = {num1 * num2}"
    return "Unsupported calculation operator"

# --- TOOL 2: LIVE CRICBUZZ API (UPDATED ROBUST HTML SELECTORS) ---
@mcp_hub.tool()
def get_live_cricket_scores() -> str:
    """Fetch live match cards and summaries directly from Cricbuzz."""
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        url = "https://www.cricbuzz.com/cricket-match/live-scores"
        response = requests.get(url, headers=headers, timeout=10)
        soup = BeautifulSoup(response.text, "html.parser")
        
        # Robust lookup: Grabs main containers for live matches
        matches = soup.find_all('div', class_="cb-lv-main")
        
        if not matches:
            # Fallback wrapper if class structures are completely dynamic
            matches = soup.find_all('div', class_="cb-col-100 cb-col cb-schdl")
            
        if not matches:
            return "No live international matches currently active or structure updated."
            
        results = []
        for index, match in enumerate(matches[:3], 1):
            # Safe text extraction pattern
            text_summary = match.get_text(separator=" | ", strip=True)
            # Shorten output string so it looks readable in console
            clean_summary = " ".join(text_summary.split()[:15]) + "..."
            results.append(f"Match {index}: {clean_summary}")
            
        return "\n".join(results)
    except Exception as e:
        return f"Cricbuzz dynamic connectivity failed: {str(e)}"

# --- TOOL 3: SYSTEM LOGGER PROTOCOL ---
@mcp_hub.tool()
def append_to_agent_logs(session_type: str, details: str) -> str:
    """Open logging text stream, write operational outputs, and close securely."""
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{session_type.upper()} LOG ENTRY]\n{details}\n")
            f.write("=" * 50 + "\n")
        return "Log sequence completed and file closed successfully."
    except Exception as e:
        return f"Logging driver error: {str(e)}"


# 3. ROUTER / CONTEXT CONTROLLER
def run_multi_agent_ecosystem():
    print("==========================================================")
    print("🤖 Local Multi-Agent Router Ready (Math, Cricbuzz, System Logs)")
    print("==========================================================")
    print("Type 'exit' to terminate context.\n")
    
    while True:
        user_query = input("Nee Question adugu: ").strip()
        if user_query.lower() in ['exit', 'quit']:
            break
        if not user_query:
            continue
            
        print("\n[Router Classifier]: Scanning prompt keywords...")
        query_lower = user_query.lower()
        
        # --- PATHWAY A: MATH SPECIALIST NODE (FIX 2: Using RegEx to grab numbers) ---
        if any(word in query_lower for word in ["sum", "add", "multiply", "plus", "+", "*"]):
            print("-> Routing to [Math Agent Specialist] Node...")
            
            # Extracts all integers/floats even if combined like 200+600
            numbers = [float(n) for n in re.findall(r"\d+\.\d+|\d+", query_lower)]
            
            if len(numbers) >= 2:
                op = "multiply" if any(x in query_lower for x in ["multiply", "*"]) else "sum"
                execution_result = compute_math_operation(operation_type=op, num1=numbers[0], num2=numbers[1])
                print(f"[Math Agent Response]: {execution_result}")
                append_to_agent_logs("Math Agent", f"Query: {user_query}\nResult: {execution_result}")
            else:
                print("[Math Agent Error]: Calculation triggers require minimum 2 numbers.")

        # --- PATHWAY B: CRICBUZZ API DATA STREAM NODE ---
        elif any(word in query_lower for word in ["score", "cricket", "cricbuzz", "match", "vs"]):
            print("-> Routing to [Cricbuzz Web Scraper API] Node...")
            print("Connecting to live scoreboard servers...")
            
            live_feed = get_live_cricket_scores()
            print(f"\n[Cricbuzz Scorecard Output]:\n{live_feed}")
            append_to_agent_logs("Cricket API Agent", f"Query: {user_query}\nData Extracted:\n{live_feed}")

        # --- PATHWAY C: GENERAL FALLBACK ---
        else:
            print("-> Routing to [General Knowledge Agent] Node...")
            prompt = f"Context: Short precise response.\nUser: {user_query}\nAssistant:"
            ai_resp = llm.invoke(prompt).strip()
            print(f"[General Agent Response]: {ai_resp}")
            append_to_agent_logs("General Agent", f"Query: {user_query}\nResponse: {ai_resp}")
            
        print("\n[System Status]: State flushed to 'agent_system_logs.txt' and context reset.\n")

if __name__ == "__main__":
    run_multi_agent_ecosystem()