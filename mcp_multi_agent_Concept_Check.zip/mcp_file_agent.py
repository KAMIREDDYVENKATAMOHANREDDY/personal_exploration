# mcp_file_agent.py
import os
from typing import Annotated
from typing_extensions import TypedDict
from mcp.server.fastmcp import FastMCP
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_community.llms import LlamaCpp

# 1. LOCAL MODEL PARAMETERS (Nee deggara unna model path ivvu)
MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=2048, verbose=False)

# 2. MCP FILE PROTOCOL TOOLS (File handle cheyadaniki Tools create chestunnam)
# Ivi normal python functions la anipించినా, MCP protocol ki clear tools la convert avtayi.
mcp_file_server = FastMCP("LocalFileProtocol")

NOTES_FILE = "my_notes.txt"

@mcp_file_server.tool()
def write_to_notes(content: str) -> str:
    """Notes file ni open chesi, andulo text rasi, file ni close chestundi."""
    try:
        with open(NOTES_FILE, "a", encoding="utf-8") as f:
            f.write(content + "\n")
        return f"Successfully text ni '{NOTES_FILE}' lo rasi close chesam."
    except Exception as e:
        return f"Error: {str(e)}"

@mcp_file_server.tool()
def read_notes() -> str:
    """Notes file ni open chesi, andulo unna matter ni motham chadivi clear ga chupistundi."""
    if not os.path.exists(NOTES_FILE):
        return "Notes file inka create avaledu, kshaminchandi."
    try:
        with open(NOTES_FILE, "r", encoding="utf-8") as f:
            data = f.read()
        return f"--- Notes Contents ---\n{data}"
    except Exception as e:
        return f"Error: {str(e)}"

# 3. LOCAL EXECUTOR (AI core logic)
def run_file_agent(user_instruction: str):
    print(f"\n[User Request]: {user_instruction}")
    
    # Simple Prompt triggering: Model ki rules cheptham
    system_prompt = (
        "Nuvvu oka File Assistant vi. User em rayali anna, 'write_to_notes' tool vadali. "
        "User em chudali anna, 'read_notes' tool vadali. "
        "Direct ga tool name and arguments mathrame format chesi ivvu."
    )
    
    prompt = f"{system_prompt}\nUser: {user_instruction}\nAssistant:"
    ai_response = llm.invoke(prompt).strip()
    
    print(f"[AI Thought Process]: {ai_response}")
    
    # 4. MCP PROTOCOL EXECUTION LOOP
    # Model select chesina option balti local script file actions perform chestundi
    if "write_to_notes" in ai_response or "rayi" in user_instruction or "write" in user_instruction:
        # Simple string processing to extract content
        # Ideal tools automated parsing kosam, kani local ga tight 1-hr loop ki idi fast shortcut
        text_to_save = user_instruction.replace("write", "").replace("notes lo rayi", "").strip()
        print("\n[MCP Action]: Opening file -> Writing content -> Closing file...")
        result = write_to_notes(content=text_to_save)
        print(f"[System Status]: {result}")
        
    elif "read_notes" in ai_response or "open" in user_instruction or "read" in user_instruction:
        print("\n[MCP Action]: Opening file -> Reading stream -> Closing context...")
        result = read_notes()
        print(result)

# --- RE-RUN TEST CASES ---
if __name__ == "__main__":
    # Test 1: File create chesi notes rayadam
    run_file_agent("notes lo rayi: I am learning LangChain and LangGraph today.")
    
    # Test 2: Inko line add cheydam
    run_file_agent("notes lo rayi: MCP file protocol working completely offline!")
    
    # Test 3: File content open chesi chudadam
    run_file_agent("Naa notes open chesi emundo chudu")