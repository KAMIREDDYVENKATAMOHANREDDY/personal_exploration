# 02_chatbot_graph.py
from typing import Annotated
from typing_extensions import TypedDict
from langchain_community.llms import LlamaCpp
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import InMemorySaver

MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=1024, verbose=False)

# 1. Define State: This defines the structure of information passed between nodes
class State(TypedDict):
    messages: Annotated[list, add_messages]

# 2. Define Node: Core execution blocks that mutate state
def chatbot_node(state: State):
    response = llm.invoke(state["messages"])
    return {"messages": [("assistant", response)]}

# 3. Build Graph Workflow
workflow = StateGraph(State)
workflow.add_node("chatbot", chatbot_node)
workflow.add_edge(START, "chatbot")
workflow.add_edge("chatbot", END)

# Memory Checkpointer to enable conversation memory across loops
memory = InMemorySaver()
app = workflow.compile(checkpointer=memory)

# --- EXECUTION ---
config = {"configurable": {"thread_id": "session_1"}}

print("--- Turn 1 ---")
events = app.stream({"messages": [("user", "Hi, my name is Alex.")]}, config)
for event in events:
    print(event)

print("\n--- Turn 2 (Testing Memory Persistence) ---")
events2 = app.stream({"messages": [("user", "What is my name?")]}, config)
for event2 in events2:
    print(event2)