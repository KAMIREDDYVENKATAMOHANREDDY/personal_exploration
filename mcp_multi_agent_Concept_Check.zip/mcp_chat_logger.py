# mcp_chat_logger.py
import os
from mcp.server.fastmcp import FastMCP
from langchain_community.llms import LlamaCpp

# 1. LOCAL MODEL PARAMETERS
# (Nee computer lo unna low-spec GGUF model path ikkada ivvu)
MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=2048, verbose=False)

# 2. THE MCP FILE PROTOCOL DRIVER
# System protocol file handlers backend engine idi
mcp_file_driver = FastMCP("AutoChatLogger")
NOTES_FILE = "my_notes.txt"

@mcp_file_driver.tool()
def append_chat_to_file(question: str, answer: str) -> str:
    """File open chesi, Question and Answer rasi, ventane close chestundi."""
    try:
        # 'a' mode (append) vadi file automatic ga open avutundi
        with open(NOTES_FILE, "a", encoding="utf-8") as f:
            f.write(f"User Question: {question}\n")
            f.write(f"AI Answer: {answer}\n")
            f.write("-" * 40 + "\n") # Line separator
        # Block mugiyagane system file automatic ga safely close aipotundi
        return f"Successfully text open chesi, content rasi close chesam."
    except Exception as e:
        return f"File system error: {str(e)}"

# 3. INTERACTIVE AGENT CORE LOOP
def start_interactive_session():
    print("=== Local AI Chat (All Q&A will save to my_notes.txt) ===")
    print("Exit avvadaniki 'exit' ani type chey.\n")
    
    while True:
        # User input execution context
        user_question = input("Nee Question: ").strip()
        
        if user_question.lower() in ['exit', 'quit']:
            print("Session closed. Text file check chesko!")
            break
            
        if not user_question:
            continue
            
        # AI prompt logic execution
        system_context = "Nuvvu oka helper vi. Precise ga direct answer matrame ivvu."
        full_prompt = f"{system_context}\nUser: {user_question}\nAssistant:"
        
        print("AI aalochistundi...")
        ai_answer = llm.invoke(full_prompt).strip()
        
        # Output terminal lo chupistham
        print(f"AI Answer: {ai_answer}\n")
        
        # --- TRUE MCP PROTOCOL PROTO-TRIGGER ---
        # AI prediction complete avvagane engine trigger automatic file storage update chestundi
        print("[MCP Protocol System Action]: Opening File -> Writing Data Stream -> Closing Context...")
        
        # Structural execution call to target text file destination
        status = append_chat_to_file(question=user_question, answer=ai_answer)
        print(f"[System Status]: {status}\n")

if __name__ == "__main__":
    start_interactive_session()