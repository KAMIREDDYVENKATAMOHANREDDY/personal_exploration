# 03_conditional_agents.py
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langchain_community.llms import LlamaCpp

MODEL_PATH = "D:\Personal\Matlab_Works\BDC_Brain\Multi_agent\qwen2.5-1.5b-instruct-q4_k_m.gguf"
llm = LlamaCpp(model_path=MODEL_PATH, n_ctx=1024, verbose=False)

class RouterState(TypedDict):
    route: str
    user_query: str
    output: str

# Node A: Classifier
def classifier_node(state: RouterState):
    query = state["user_query"].lower()
    # Mocking standard deterministic matching or simple LLM choice logic
    if "code" in query or "python" in query:
        chosen_route = "coder"
    else:
        chosen_route = "writer"
    return {"route": chosen_route}

# Node B: Coder Specialist
def coder_node(state: RouterState):
    return {"output": "Executed Code Agent: Here is your clean Python logic."}

# Node C: Writer Specialist
def writer_node(state: RouterState):
    return {"output": "Executed Writer Agent: Once upon a time, a prompt arrived..."}

# Conditional Routing Logic Function
def route_decision(state: RouterState):
    return state["route"] # Returns string mapping exactly to node name

# Graph Construction
builder = StateGraph(RouterState)
builder.add_node("classifier", classifier_node)
builder.add_node("coder", coder_node)
builder.add_node("writer", writer_node)

builder.add_edge(START, "classifier")

# Conditional Edges decide execution paths dynamically at runtime
builder.add_conditional_edges(
    "classifier",
    route_decision,
    {
        "coder": "coder",
        "writer": "writer"
    }
)

builder.add_edge("coder", END)
builder.add_edge("writer", END)

graph = builder.compile()

# Test Runner
res = graph.invoke({"user_query": "Write a python script to count file sizes"})
print(f"Result for code query: {res['output']}")

res2 = graph.invoke({"user_query": "Tell me an epic historical story"})
print(f"Result for creative query: {res2['output']}")