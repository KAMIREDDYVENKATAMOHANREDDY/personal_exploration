# src/step4_extract_data.py
import xml.etree.ElementTree as ET
from ir_models import NodeIR
import json
import os

def extract_data_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    extracted_data_nodes = []

    # Find ALL <data> tags
    for data_tag in root.iter('data'):
        # 1. Get ID and Name (Notice that Name is a direct attribute here, not inside a <P> tag!)
        data_id = data_tag.get('SSID')
        data_name = data_tag.get('name')
        
        # 2. Create our NodeIR
        node = NodeIR(node_id=data_id, node_type="Stateflow_Data", name=data_name)
        
        # 3. Extract properties like Scope, DataType, Description
        for p_tag in data_tag.findall('P'):
            prop_name = p_tag.get('Name')
            prop_value = p_tag.text
            node.properties[prop_name] = prop_value
                
        extracted_data_nodes.append(node.to_dict())

    return extracted_data_nodes

# --- TEST CODE ---
if __name__ == "__main__":
    current_dir = os.path.dirname(__file__)
    xml_file_path = os.path.join(current_dir, "..", "data", "simulink", "stateflow", "dummy_chart.xml")
    
    print(f"Extracting Variables from XML...")
    
    # Extract and print
    variables = extract_data_from_xml(xml_file_path)
    print(json.dumps(variables, indent=2))