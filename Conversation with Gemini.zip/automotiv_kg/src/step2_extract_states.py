# # # src/step2_extract_states.py
# # import xml.etree.ElementTree as ET
# # from ir_models import NodeIR
# # import json
# # import os

# # def extract_states_from_xml(xml_path):
# #     # Load the XML file
# #     tree = ET.parse(xml_path)
# #     root = tree.getroot()
    
# #     extracted_nodes = []

# #     # Find ALL <State> tags in the XML, no matter where they are
# #     for state_tag in root.iter('State'):
# #         # 1. Get the State ID (SSID)
# #         state_id = state_tag.get('SSID')
        
# #         # 2. Get the State Name (stored inside <P Name="labelString">)
# #         state_name = "Unknown_State"
# #         for p_tag in state_tag.findall('P'):
# #             if p_tag.get('Name') == 'labelString':
# #                 state_name = p_tag.text
# #                 break # Found the name, stop looking
                
# #         # 3. Create our IR Node
# #         node = NodeIR(node_id=state_id, node_type="Stateflow_State", name=state_name)
        
# #         # 4. Save extra properties to avoid Information Loss
# #         for p_tag in state_tag.findall('P'):
# #             prop_name = p_tag.get('Name')
# #             prop_value = p_tag.text
# #             if prop_name != 'labelString': # We already have the name
# #                 node.properties[prop_name] = prop_value
                
# #         extracted_nodes.append(node.to_dict())

# #     return extracted_nodes

# # # --- TEST CODE ---
# # if __name__ == "__main__":
# #     # Get the correct path to the dummy XML
# #     current_dir = os.path.dirname(__file__)
# #     xml_file_path = os.path.join(current_dir, "..", "data", "simulink", "stateflow", "dummy_chart.xml")
    
# #     print(f"Reading XML from: {xml_file_path}")
    
# #     # Extract and print
# #     states = extract_states_from_xml(xml_file_path)
# #     print(json.dumps(states, indent=2))



# # src/step2_extract_states.py
# import xml.etree.ElementTree as ET

# def extract_states_from_xml(xml_path):
#     tree = ET.parse(xml_path)
#     root = tree.getroot()
#     nodes = []

#     # Find all states
#     for state in root.findall('.//state') + root.findall('.//State'):
#         state_id = state.get('SSID') or state.get('id')
#         state_name = state.get('name', 'Unknown_State')
        
#         properties = {}
        
#         # --- NEW LOGIC: Extract labelString for Actions ---
#         label_text = state.get('labelString')
#         if not label_text:
#             label_elem = state.find('labelString')
#             if label_elem is not None:
#                 label_text = label_elem.text
#             else:
#                 for p in state.findall('.//P'):
#                     if p.get('Name') == 'labelString':
#                         label_text = p.text
#                         break
        
#         # Save raw label and try to split entry/during/exit
#         if label_text:
#             properties['labelString'] = label_text
            
#             # Simple parsing for en, du, ex
#             lines = label_text.split('\n')
#             for line in lines:
#                 line = line.strip()
#                 if line.startswith('en:'): properties['entryAction'] = line
#                 elif line.startswith('du:'): properties['duringAction'] = line
#                 elif line.startswith('ex:'): properties['exitAction'] = line

#         if state_id:
#             nodes.append({
#                 "id": f"state_{state_id}",
#                 "name": state_name,
#                 "type": "State",
#                 "properties": properties
#             })
            
#     return nodes

# if __name__ == "__main__":
#     # Test path
#     pass


# src/step2_extract_states.py
import xml.etree.ElementTree as ET

def extract_states_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    nodes = []

    for state in root.findall('.//state') + root.findall('.//State'):
        state_id = state.get('SSID') or state.get('id')
        state_name = state.get('name', 'Unknown_State')
        properties = {}
        
        # 1. Extract labelString
        label_text = state.get('labelString')
        if not label_text:
            label_elem = state.find('labelString')
            if label_elem is not None: 
                label_text = label_elem.text
            else:
                for p in state.findall('.//P'):
                    if p.get('Name') == 'labelString':
                        label_text = p.text
                        break
        
        if label_text:
            properties['labelString'] = label_text
            
            # Clean empty lines
            lines = [line.strip() for line in label_text.split('\n') if line.strip()]
            
            # FIX 1: Grab the actual State Name from the first line
            if state_name == 'Unknown_State' and len(lines) > 0:
                state_name = lines[0]
                
            # FIX 2: Smartly extract entry, during, exit actions (multi-line)
            if 'en:' in label_text:
                # Get everything after 'en:' but before 'du:' or 'ex:'
                en_part = label_text.split('en:')[1].split('du:')[0].split('ex:')[0].strip()
                properties['entryAction'] = en_part
                
            if 'du:' in label_text:
                du_part = label_text.split('du:')[1].split('en:')[0].split('ex:')[0].strip()
                properties['duringAction'] = du_part
                
            if 'ex:' in label_text:
                ex_part = label_text.split('ex:')[1].split('en:')[0].split('du:')[0].strip()
                properties['exitAction'] = ex_part

        if state_id:
            nodes.append({
                "id": f"state_{state_id}",
                "name": state_name,
                "type": "State",
                "properties": properties
            })
            
    return nodes

if __name__ == "__main__":
    pass