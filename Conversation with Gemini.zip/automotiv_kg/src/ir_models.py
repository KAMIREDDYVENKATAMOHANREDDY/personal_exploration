# src/ir_models.py
import json

class NodeIR:
    def __init__(self, node_id, node_type, name=""):
        self.id = node_id           # e.g., "ssid_24"
        self.type = node_type       # e.g., "Stateflow_State"
        self.name = name            # e.g., "Engine_Running"
        self.properties = {}        # The magic bucket for zero information loss!

    def to_dict(self):
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "properties": self.properties
        }

class EdgeIR:
    def __init__(self, edge_id, source_id, target_id, edge_type):
        self.id = edge_id           # e.g., "trans_55"
        self.source = source_id     # e.g., "ssid_24"
        self.target = target_id     # e.g., "ssid_25"
        self.type = edge_type       # e.g., "TRANSITION"
        self.properties = {}        # Magic bucket for edge conditions, execution orders, etc.

    def to_dict(self):
        return {
            "id": self.id,
            "source": self.source,
            "target": self.target,
            "type": self.type,
            "properties": self.properties
        }

# --- TEST CODE ---
if __name__ == "__main__":
    # Let's test it by creating a dummy state
    dummy_state = NodeIR(node_id="101", node_type="Stateflow_State", name="Idle")
    dummy_state.properties["description"] = "System is waiting"
    
    print("Testing Node IR:")
    print(json.dumps(dummy_state.to_dict(), indent=2))