# # src/step3_extract_transitions.py
# import xml.etree.ElementTree as ET
# from ir_models import EdgeIR
# import json
# import os

# def extract_transitions_from_xml(xml_path):
#     tree = ET.parse(xml_path)
#     root = tree.getroot()
    
#     extracted_edges = []

#     # Find ALL <transition> tags
#     for trans_tag in root.iter('transition'):
#         trans_id = trans_tag.get('SSID')
        
#         # Extract Source and Destination SSIDs safely
#         src_tag = trans_tag.find('.//src/SSID')
#         dst_tag = trans_tag.find('.//dst/SSID')
        
#         src_id = src_tag.text if src_tag is not None else None
#         dst_id = dst_tag.text if dst_tag is not None else None
        
#         # Create our EdgeIR
#         edge = EdgeIR(edge_id=trans_id, source_id=src_id, target_id=dst_id, edge_type="Stateflow_Transition")
        
#         # Get the condition from labelString
#         for p_tag in trans_tag.findall('P'):
#             if p_tag.get('Name') == 'labelString':
#                 edge.properties['condition'] = p_tag.text
                
#         extracted_edges.append(edge.to_dict())

#     return extracted_edges

# # --- TEST CODE ---
# if __name__ == "__main__":
#     current_dir = os.path.dirname(__file__)
#     xml_file_path = os.path.join(current_dir, "..", "data", "simulink", "stateflow", "dummy_chart.xml")
    
#     print(f"Reading Transitions from XML...")
    
#     # Extract and print
#     transitions = extract_transitions_from_xml(xml_file_path)
#     print(json.dumps(transitions, indent=2))


# src/step3_extract_transitions.py
import xml.etree.ElementTree as ET

def extract_transitions_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    edges = []

    for trans in root.findall('.//transition') + root.findall('.//Transition'):
        src_id = None
        dst_id = None
        
        # Look for source and destination IDs
        for p in trans.findall('.//P'):
            if p.get('Name') == 'SSID':
                # Sometimes transitions have their own ID, ignore here
                pass
        
        # Safely get src and dst
        src_elem = trans.find('.//src/id') if trans.find('.//src/id') is not None else trans.find('.//src/SSID')
        dst_elem = trans.find('.//dst/id') if trans.find('.//dst/id') is not None else trans.find('.//dst/SSID')
        
        if src_elem is None:
            # Fallback for newer XML formats
            src_elem = trans.find('.//src')
            dst_elem = trans.find('.//dst')
            if src_elem is not None: src_id = src_elem.get('SSID')
            if dst_elem is not None: dst_id = dst_elem.get('SSID')
        else:
            src_id = src_elem.text
            dst_id = dst_elem.text

        if src_id and dst_id:
            properties = {}
            
            # --- NEW LOGIC: Extract Transition Conditions / Actions ---
            label_text = trans.get('labelString')
            if not label_text:
                label_elem = trans.find('labelString')
                if label_elem is not None:
                    label_text = label_elem.text
                else:
                    for p in trans.findall('.//P'):
                        if p.get('Name') == 'labelString':
                            label_text = p.text
                            break
                            
            if label_text:
                properties['condition_action'] = label_text

            edges.append({
                "source": f"state_{src_id}",
                "target": f"state_{dst_id}",
                "type": "TRANSITION",
                "properties": properties
            })
            
    return edges

if __name__ == "__main__":
    pass