# src/step11_batch_extractor.py
import os
import glob
import json
import zipfile
import tempfile

# 1. Correct Imports based on your step7 !
from step2_extract_states import extract_states_from_xml
from step3_extract_transitions import extract_transitions_from_xml
from step4_extract_data import extract_data_from_xml
from step5_extract_blocks import extract_blocks_from_xml
from step6_extract_lines import extract_lines_from_xml

def batch_extract():
    current_dir = os.path.dirname(__file__)
    raw_models_dir = os.path.join(current_dir, "..", "data", "raw_models")
    output_dir = os.path.join(current_dir, "..", "output")
    
    # Ensure directories exist
    os.makedirs(raw_models_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    all_nodes = []
    all_edges = []
    
    # Get all .slx (or .zip) files
    slx_files = [f for f in os.listdir(raw_models_dir) if f.endswith('.slx') or f.endswith('.zip')]
    
    if not slx_files:
        print(f"No .slx files found in 'data/raw_models/'!")
        return

    print(f"Found {len(slx_files)} models. Starting Batch Extraction...\n")

    for filename in slx_files:
        model_name = os.path.splitext(filename)[0]
        file_path = os.path.join(raw_models_dir, filename)
        
        print(f"Processing: {model_name}...")
        
        with tempfile.TemporaryDirectory() as temp_dir:
            try:
                # 1. Unzip the SLX file to temp directory
                with zipfile.ZipFile(file_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                model_nodes = []
                model_edges = []

                # 2. Extract Stateflow using your existing functions
                stateflow_xmls = glob.glob(os.path.join(temp_dir, "simulink", "stateflow", "*.xml"))
                for xml_file in stateflow_xmls:
                    model_nodes.extend(extract_states_from_xml(xml_file))
                    model_nodes.extend(extract_data_from_xml(xml_file))
                    model_edges.extend(extract_transitions_from_xml(xml_file))

                # 3. Extract Simulink using your existing functions
                simulink_xmls = glob.glob(os.path.join(temp_dir, "simulink", "systems", "*.xml"))
                for xml_file in simulink_xmls:
                    model_nodes.extend(extract_blocks_from_xml(xml_file))
                    model_edges.extend(extract_lines_from_xml(xml_file))

                # 4. MAGIC STEP: Make IDs unique and tag the Model Name
                for node in model_nodes:
                    old_id = node['id']
                    node['id'] = f"{model_name}_{old_id}"
                    
                    # Ensure properties dict exists
                    if 'properties' not in node:
                        node['properties'] = {}
                        
                    node['properties']['ParentModel'] = model_name
                    all_nodes.append(node)
                    
                for edge in model_edges:
                    edge['source'] = f"{model_name}_{edge['source']}"
                    edge['target'] = f"{model_name}_{edge['target']}"
                    
                    # Ensure properties dict exists
                    if 'properties' not in edge:
                        edge['properties'] = {}
                        
                    edge['properties']['ParentModel'] = model_name
                    all_edges.append(edge)
                    
                print(f"  -> Extracted {len(model_nodes)} nodes and {len(model_edges)} edges.")
                
            except Exception as e:
                print(f"  -> Error processing {filename}: {e}")

    # 5. Save the Master Database Files
    nodes_path = os.path.join(output_dir, "batch_nodes.json")
    edges_path = os.path.join(output_dir, "batch_edges.json")
    
    with open(nodes_path, 'w') as f:
        json.dump(all_nodes, f, indent=4)
    with open(edges_path, 'w') as f:
        json.dump(all_edges, f, indent=4)
        
    print(f"\nSUCCESS! Master Knowledge Graph generated.")
    print(f"Total Nodes from all {len(slx_files)} models: {len(all_nodes)}")
    print(f"Total Edges from all {len(slx_files)} models: {len(all_edges)}")
    print(f"Saved safely to 'output/batch_nodes.json' and 'batch_edges.json'.")

if __name__ == "__main__":
    batch_extract()