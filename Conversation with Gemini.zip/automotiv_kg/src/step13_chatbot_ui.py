# src/step13_chatbot_ui.py
import os
import tkinter as tk
from tkinter import scrolledtext
import threading

from langchain_neo4j import Neo4jGraph, GraphCypherQAChain
from langchain_community.llms import LlamaCpp
from langchain_core.callbacks import BaseCallbackHandler

# 1. SETUP CREDENTIALS
os.environ["NEO4J_URI"] = "neo4j://127.0.0.1:7687"
os.environ["NEO4J_USERNAME"] = "neo4j"
os.environ["NEO4J_PASSWORD"] = "password123"  # Change if needed

# 2. CUSTOM CALLBACK HANDLER (For live typing in UI)
class TkinterCallbackHandler(BaseCallbackHandler):
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def on_llm_new_token(self, token: str, **kwargs) -> None:
        # Live ga prathi word ni UI lo print chesthundi
        self.text_widget.insert(tk.END, token)
        self.text_widget.see(tk.END)
        self.text_widget.update_idletasks()

# 3. THE CHATBOT APP CLASS
class AutomotiveSMEApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Automotive SME Assistant (Offline)")
        self.root.geometry("800x600")
        self.root.configure(bg="#1e1e1e")

        # Title
        title_label = tk.Label(root, text="🚘 Automotive Systems Knowledge Graph", 
                               font=("Helvetica", 16, "bold"), bg="#1e1e1e", fg="#4CAF50")
        title_label.pack(pady=10)

        # Chat Window
        self.chat_display = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Consolas", 11), 
                                                      bg="#2d2d2d", fg="#ffffff", padx=10, pady=10)
        self.chat_display.pack(padx=20, pady=5, fill=tk.BOTH, expand=True)
        self.chat_display.insert(tk.END, "System: Waking up AI and connecting to Neo4j... Please wait.\n\n")
        self.chat_display.configure(state='disabled')

        # Input Area
        input_frame = tk.Frame(root, bg="#1e1e1e")
        input_frame.pack(padx=20, pady=10, fill=tk.X)

        self.user_input = tk.Entry(input_frame, font=("Helvetica", 12), bg="#3d3d3d", fg="#ffffff", insertbackground="white")
        self.user_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10), ipady=5)
        self.user_input.bind("<Return>", self.send_message)

        self.send_btn = tk.Button(input_frame, text="Ask AI", font=("Helvetica", 11, "bold"), 
                                  bg="#4CAF50", fg="white", command=self.send_message)
        self.send_btn.pack(side=tk.RIGHT, ipadx=10, ipady=3)

        # Initialization
        self.chain = None
        # Start AI load in background so UI doesn't freeze
        threading.Thread(target=self.init_ai, daemon=True).start()

    def update_chat(self, sender, message, color="#ffffff"):
        self.chat_display.configure(state='normal')
        self.chat_display.insert(tk.END, f"{sender}: ", ("bold",))
        self.chat_display.insert(tk.END, f"{message}\n\n", ("msg",))
        self.chat_display.see(tk.END)
        self.chat_display.configure(state='disabled')

    def init_ai(self):
        try:
            # Connect Database
            graph = Neo4jGraph()
            graph.refresh_schema()
            
            # Load Local Model
            current_dir = os.path.dirname(__file__)
            model_path = os.path.join(current_dir, "..", "models", "Phi-3.5-mini-instruct-Q5_K_S.gguf")
            
            llm = LlamaCpp(
                model_path=model_path,
                temperature=0,
                n_ctx=2048,
                max_tokens=500,
                callbacks=[TkinterCallbackHandler(self.chat_display)],
                verbose=False
            )
            
            # Create Chain with a Custom Prompt to avoid Hallucinations
            # Create Chain with a Custom Prompt for Dependency Tracing
            from langchain_core.prompts import PromptTemplate
            cypher_prompt = PromptTemplate(
                input_variables=["schema", "question"],
                template="""You are a Neo4j Cypher expert for Automotive Simulink/Stateflow models.
                Use ONLY the provided schema to answer the user's question.

                CRITICAL RULES:
                1. SIGNAL DEPENDENCIES: To find dependencies or trace signals, use variable-length paths. Example: `MATCH path = (source)-[:CONNECTED_TO*1..3]->(target:Entity {{name: 'TargetName'}}) RETURN path`
                2. STATE LOGIC: To explain how a state turns on, find the incoming TRANSITION edge and return its `condition_action` property. Example: `MATCH ()-[r:TRANSITION]->(s:Entity {{name: 'StateName'}}) RETURN r.condition_action`
                3. Do not invent properties. Always use 'name' to identify blocks/states.

                Schema: {schema}
                Question: {question}
                Cypher Query:"""
            )

            self.chain = GraphCypherQAChain.from_llm(
                cypher_llm=llm,       
                qa_llm=llm,           
                graph=graph,          
                verbose=True,
                cypher_prompt=cypher_prompt,
                allow_dangerous_requests=True
            )
            
            self.update_chat("System", "Ready! AI is fully loaded. Ask me about your Simulink models.", "#4CAF50")
        
        except Exception as e:
            self.update_chat("System Error", str(e), "#ff4444")

    def send_message(self, event=None):
        msg = self.user_input.get().strip()
        if not msg or not self.chain:
            return
            
        self.user_input.delete(0, tk.END)
        self.update_chat("You", msg)
        
        self.chat_display.configure(state='normal')
        self.chat_display.insert(tk.END, "AI Assistant: ", ("bold",))
        self.chat_display.see(tk.END)
        
        # Run AI generation in a separate thread so the UI doesn't freeze
        threading.Thread(target=self.generate_response, args=(msg,), daemon=True).start()

    def generate_response(self, question):
        try:
            # The custom callback will type the response directly into the UI!
            self.chain.invoke({"query": question})
            self.chat_display.insert(tk.END, "\n\n")
            self.chat_display.see(tk.END)
        except Exception as e:
            self.chat_display.insert(tk.END, f"\n[Error: {str(e)}]\n\n")
        finally:
            self.chat_display.configure(state='disabled')

if __name__ == "__main__":
    root = tk.Tk()
    app = AutomotiveSMEApp(root)
    root.mainloop()