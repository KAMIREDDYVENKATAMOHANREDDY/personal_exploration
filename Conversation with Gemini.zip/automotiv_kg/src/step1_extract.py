from pathlib import Path
import zipfile

MODEL_FILE = "../models/Door_Lock_Unlock.slx"
EXTRACT_FOLDER = "../extracted"

Path(EXTRACT_FOLDER).mkdir(exist_ok=True)

with zipfile.ZipFile(MODEL_FILE, 'r') as zip_ref:
    zip_ref.extractall(EXTRACT_FOLDER)

print("SLX extracted successfully")