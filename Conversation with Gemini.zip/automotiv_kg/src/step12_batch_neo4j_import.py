# src/step12_batch_neo4j_import.py
from neo4j import GraphDatabase
import json
import os

# Neo4j Credentials
NEO4J_URI = "neo4j://127.0.0.1:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "password123"  # Nee password idhe ga

def load_batch_data():
    current_dir = os.path.dirname(__file__)
    # Pointing to the new BATCH files!
    nodes_path = os.path.join(current_dir, "..", "output", "batch_nodes.json")
    edges_path = os.path.join(current_dir, "..", "output", "batch_edges.json")
    
    with open(nodes_path, 'r') as f:
        nodes = json.load(f)
    with open(edges_path, 'r') as f:
        edges = json.load(f)
    return nodes, edges

def ingest_batch_to_neo4j():
    nodes, edges = load_batch_data()
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

    with driver.session() as session:
        # 1. Clear old single-model data
        print("Clearing old graph to make way for the Master Graph...")
        session.run("MATCH (n) DETACH DELETE n")

        # 2. Insert all Nodes from all 4 models
        print(f"Inserting {len(nodes)} nodes from 4 models...")
        node_query = """
        UNWIND $nodes AS n
        MERGE (node:Entity {id: n.id})
        SET node.name = n.name,
            node.type = n.type,
            node += n.properties
        """
        session.run(node_query, nodes=nodes)

        # 3. Insert all Edges
        print(f"Inserting {len(edges)} edges...")
        edge_query = """
        UNWIND $edges AS e
        MATCH (source:Entity {id: e.source})
        MATCH (target:Entity {id: e.target})
        MERGE (source)-[rel:CONNECTED_TO]->(target)
        SET rel.type = e.type,
            rel += e.properties
        """
        session.run(edge_query, edges=edges)

    driver.close()
    print("SUCCESS! Master Graph migrated to Neo4j.")

if __name__ == "__main__":
    ingest_batch_to_neo4j()