# src/step6_extract_lines.py
import xml.etree.ElementTree as ET
from ir_models import EdgeIR
import json
import os

def extract_lines_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    extracted_edges = []
    line_counter = 1

    # Helper function to handle <Line> and nested <Branch> tags
    def process_connection(element, parent_src=None):
        nonlocal line_counter
        
        local_src = None
        local_dst = None
        
        # Look for Src and Dst inside this specific Line or Branch
        for p in element.findall('P'):
            if p.get('Name') == 'Src':
                local_src = p.text
            elif p.get('Name') == 'Dst':
                local_dst = p.text
        
        # If this is a branch, it might not have a Src. It inherits from its parent!
        current_src = local_src if local_src else parent_src
        
        # If we have both a Source and a Destination, we have a valid wire!
        if current_src and local_dst:
            # Clean the ID (e.g., convert "2#out:1" to just "2" for the main Node ID)
            src_block_id = current_src.split('#')[0]
            dst_block_id = local_dst.split('#')[0]
            
            edge = EdgeIR(
                edge_id=f"line_{line_counter}",
                source_id=src_block_id,
                target_id=dst_block_id,
                edge_type="Simulink_SignalLine"
            )
            
            # Save the exact port info into properties to avoid info loss!
            edge.properties['src_port'] = current_src
            edge.properties['dst_port'] = local_dst
            
            extracted_edges.append(edge.to_dict())
            line_counter += 1
            
        # RECUSRION: Check if there are any <Branch> tags inside this element
        for branch in element.findall('Branch'):
            process_connection(branch, current_src)

    # ---------------------------------------------------------
    # 1. Find all main <Line> tags in the XML and process them
    for line_tag in root.iter('Line'):
        process_connection(line_tag)

    return extracted_edges

# --- TEST CODE ---
if __name__ == "__main__":
    current_dir = os.path.dirname(__file__)
    xml_file_path = os.path.join(current_dir, "..", "data", "simulink", "systems", "dummy_system.xml")
    
    print(f"Extracting Simulink Lines & Branches...")
    
    lines = extract_lines_from_xml(xml_file_path)
    print(json.dumps(lines, indent=2))