# src/step9_neo4j_import.py
from neo4j import GraphDatabase
import json
import os

# ---> IMPORTANT: Update these with your Neo4j credentials <---
NEO4J_URI = "neo4j://127.0.0.1:7687"  # Or your Neo4j Aura URI (neo4j+s://...)
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "password123"          # Change this to your password!

def load_json_data():
    current_dir = os.path.dirname(__file__)
    with open(os.path.join(current_dir, "..", "output", "nodes.json"), 'r') as f:
        nodes = json.load(f)
    with open(os.path.join(current_dir, "..", "output", "edges.json"), 'r') as f:
        edges = json.load(f)
    return nodes, edges

def ingest_to_neo4j():
    nodes, edges = load_json_data()
    driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))

    with driver.session() as session:
        # 1. Clear existing database (Careful: This deletes everything in Neo4j!)
        print("Clearing old graph...")
        session.run("MATCH (n) DETACH DELETE n")

        # 2. Insert Nodes
        # We use a generic label 'Entity' and save the actual type as a property
        print(f"Inserting {len(nodes)} nodes...")
        node_query = """
        UNWIND $nodes AS n
        MERGE (node:Entity {id: n.id})
        SET node.name = n.name,
            node.type = n.type,
            node += n.properties  // Magic! Attaches all extracted properties dynamically
        """
        session.run(node_query, nodes=nodes)

        # 3. Insert Edges
        print(f"Inserting {len(edges)} edges...")
        edge_query = """
        UNWIND $edges AS e
        MATCH (source:Entity {id: e.source})
        MATCH (target:Entity {id: e.target})
        // We use APOC-like dynamic relationship creation by setting property 'type'
        // Standard Cypher doesn't allow dynamic relationship types easily, 
        // so we use a generic 'CONNECTED_TO' and store the real type.
        MERGE (source)-[rel:CONNECTED_TO]->(target)
        SET rel.type = e.type,
            rel += e.properties
        """
        session.run(edge_query, edges=edges)

    driver.close()
    print("SUCCESS! Data migrated to Neo4j.")

if __name__ == "__main__":
    try:
        ingest_to_neo4j()
    except Exception as e:
        print("Error connecting to Neo4j. Check your URI and Password!")
        print(e)