# src/step8_networkx_graph.py
import json
import networkx as nx
import os

def load_graph_to_networkx():
    # Paths to our JSON files
    current_dir = os.path.dirname(__file__)
    nodes_path = os.path.join(current_dir, "..", "output", "nodes.json")
    edges_path = os.path.join(current_dir, "..", "output", "edges.json")

    # Load JSON data
    with open(nodes_path, 'r') as f:
        nodes_data = json.load(f)
    with open(edges_path, 'r') as f:
        edges_data = json.load(f)

    # Initialize a Directed Graph
    G = nx.DiGraph()

    # Add Nodes
    for node in nodes_data:
        G.add_node(
            node['id'], 
            type=node['type'], 
            name=node['name'], 
            **node.get('properties', {}) # Unpack properties into the node
        )

    # Add Edges
    for edge in edges_data:
        G.add_edge(
            edge['source'], 
            edge['target'], 
            edge_id=edge['id'],
            type=edge['type'],
            **edge.get('properties', {}) # Unpack edge properties
        )

    print(f"Graph loaded successfully!")
    print(f"Total Nodes: {G.number_of_nodes()}")
    print(f"Total Edges: {G.number_of_edges()}\n")

    # --- GRAPH QUERY TEST ---
    print("--- GRAPH QUERY: Tracing the Mux Signal ---")
    
    # We know our Mux from Phase 7 had ID "2". Let's ask the graph what it connects to!
    mux_id = "2"
    
    if mux_id in G:
        mux_name = G.nodes[mux_id].get('name', 'Unknown')
        print(f"Found Node '{mux_name}' (ID: {mux_id})")
        
        # Get successors (nodes that the Mux points to)
        successors = list(G.successors(mux_id))
        
        print(f"It sends signals to {len(successors)} block(s):")
        for target_id in successors:
            target_node = G.nodes[target_id]
            edge_data = G.get_edge_data(mux_id, target_id)
            print(f"  -> {target_node['name']} ({target_node['type']}) | via port: {edge_data['dst_port']}")
    else:
        print("Mux node not found. Check if previous phases generated IDs correctly.")

if __name__ == "__main__":
    load_graph_to_networkx()