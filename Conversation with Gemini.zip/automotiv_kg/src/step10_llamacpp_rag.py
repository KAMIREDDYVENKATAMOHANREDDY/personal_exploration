# src/step10_llamacpp_rag.py
import os
from langchain_neo4j import Neo4jGraph, GraphCypherQAChain  # <--- Both from here now!
from langchain_community.llms import LlamaCpp
from langchain_core.callbacks import StreamingStdOutCallbackHandler

# 1. SETUP NEO4J CREDENTIALS
os.environ["NEO4J_URI"] = "neo4j://127.0.0.1:7687"
os.environ["NEO4J_USERNAME"] = "neo4j"
os.environ["NEO4J_PASSWORD"] = "password123" # Ikkada nee password pettu

def run_llamacpp_graph_rag():
    print("Connecting to local Neo4j Graph...")
    
    # 2. CONNECT TO NEO4J
    graph = Neo4jGraph()
    graph.refresh_schema()
    print("\nGraph Schema loaded successfully!")

    # 3. INITIALIZE LLAMA-CPP ENGINE
    # Ikkada nuvvu download chesina .gguf file exact name pettu
    current_dir = os.path.dirname(__file__)
    model_path = os.path.join(current_dir, "..", "models", "Phi-3.5-mini-instruct-Q5_K_S.gguf") 
    
    print(f"Loading Local Model from: {model_path}...")
    
    # Callbacks let us see the model typing in real-time
    
    try:
        llm = LlamaCpp(
            model_path=model_path,
            temperature=0,
            n_ctx=2048,
            max_tokens=500,
            callbacks=[StreamingStdOutCallbackHandler()], # <--- Changed here
            verbose=False
        )
    except Exception as e:
        print("\nError loading the model! Did you download the .gguf file and put it in the models folder?")
        print(e)
        return

    # 4. CREATE THE GRAPHRAG CHAIN
    chain = GraphCypherQAChain.from_llm(
        cypher_llm=llm,       
        qa_llm=llm,           
        graph=graph,          
        verbose=True,         # Shows the generated Cypher query
        allow_dangerous_requests=True
    )

    # 5. TEST WITH YOUR REAL DATA
    print("\n--- ASK YOUR Llama.cpp AI ---")
    question = "Write a Cypher query to MATCH 5 nodes with the label 'Entity'. Return their 'name' and 'type' properties."
    
    print(f"User: {question}\n")
    print("AI is thinking...")
    
    try:
        # Note: Chinna SLMs ki cypher syntax prompt koncham kastam ga anipinchachu. 
        # But let's see how it handles your schema!
        response = chain.invoke({"query": question})
        # The result will be streamed live to the console, but we can also print the final chunk:
        print(f"\nFinal Result: {response['result']}")
    except Exception as e:
        print(f"\nOops! Error: {e}")

if __name__ == "__main__":
    run_llamacpp_graph_rag()