# src/step7_build_graph_json.py
import os
import glob
import json

# Import the functions we wrote in the previous phases
from step2_extract_states import extract_states_from_xml
from step3_extract_transitions import extract_transitions_from_xml
from step4_extract_data import extract_data_from_xml
from step5_extract_blocks import extract_blocks_from_xml
from step6_extract_lines import extract_lines_from_xml

def build_master_graph():
    # Setup paths
    current_dir = os.path.dirname(__file__)
    data_dir = os.path.join(current_dir, "..", "data")
    output_dir = os.path.join(current_dir, "..", "output")
    
    # Create output folder if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    all_nodes = []
    all_edges = []

    print("--- STARTING MASTER EXTRACTION PIPELINE ---")

    # 1. PROCESS STATEFLOW FILES
    # Look for ANY xml file inside the stateflow folder
    stateflow_xmls = glob.glob(os.path.join(data_dir, "simulink", "stateflow", "*.xml"))
    for xml_file in stateflow_xmls:
        print(f"Processing Stateflow file: {os.path.basename(xml_file)}")
        all_nodes.extend(extract_states_from_xml(xml_file))
        all_nodes.extend(extract_data_from_xml(xml_file))
        all_edges.extend(extract_transitions_from_xml(xml_file))

    # 2. PROCESS SIMULINK FILES
    # Look for ANY xml file inside the systems folder
    simulink_xmls = glob.glob(os.path.join(data_dir, "simulink", "systems", "*.xml"))
    for xml_file in simulink_xmls:
        print(f"Processing Simulink file: {os.path.basename(xml_file)}")
        all_nodes.extend(extract_blocks_from_xml(xml_file))
        all_edges.extend(extract_lines_from_xml(xml_file))

    # 3. SAVE TO JSON
    nodes_path = os.path.join(output_dir, "nodes.json")
    edges_path = os.path.join(output_dir, "edges.json")

    with open(nodes_path, 'w') as f:
        json.dump(all_nodes, f, indent=2)
        
    with open(edges_path, 'w') as f:
        json.dump(all_edges, f, indent=2)

    print(f"\nSUCCESS! Extracted {len(all_nodes)} Nodes and {len(all_edges)} Edges.")
    print(f"Saved to:\n- {nodes_path}\n- {edges_path}")

if __name__ == "__main__":
    build_master_graph()