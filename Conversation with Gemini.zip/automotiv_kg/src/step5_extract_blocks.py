# src/step5_extract_blocks.py
import xml.etree.ElementTree as ET
from ir_models import NodeIR
import json
import os

def extract_blocks_from_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    
    extracted_blocks = []

    # Find ALL <Block> tags anywhere in the file
    for block_tag in root.iter('Block'):
        block_type = block_tag.get('BlockType')
        block_name = block_tag.get('Name')
        block_sid = block_tag.get('SID')
        
        # Combine "Simulink_" with the block type (e.g., Simulink_Mux, Simulink_Gain)
        node_type = f"Simulink_{block_type}"
        
        # Create NodeIR
        node = NodeIR(node_id=block_sid, node_type=node_type, name=block_name)
        
        # Extract ALL inner properties (<P> tags) to avoid information loss
        for p_tag in block_tag.findall('P'):
            prop_name = p_tag.get('Name')
            prop_value = p_tag.text
            node.properties[prop_name] = prop_value
            
        extracted_blocks.append(node.to_dict())

    return extracted_blocks

# --- TEST CODE ---
if __name__ == "__main__":
    current_dir = os.path.dirname(__file__)
    # Note: Going to systems folder this time!
    xml_file_path = os.path.join(current_dir, "..", "data", "simulink", "systems", "dummy_system.xml")
    
    print(f"Extracting Simulink Blocks...")
    
    blocks = extract_blocks_from_xml(xml_file_path)
    print(json.dumps(blocks, indent=2))