import xml.etree.ElementTree as ET
import os


def load_xml(xml_file):

    tree = ET.parse(xml_file)

    return tree.getroot()


def extract_blocks(root):

    blocks = []

    for block in root.iter("Block"):

        blocks.append({

            "sid": block.get("SID"),

            "name": block.get("Name"),

            "type": block.get("BlockType")

        })

    return blocks


def extract_connections(root):

    connections = []

    for line in root.iter("Line"):

        source = None

        for p in line.findall("P"):

            if p.attrib.get("Name") == "Src":

                source = p.text

        for branch in line.findall("Branch"):

            for p in branch.findall("P"):

                if p.attrib.get("Name") == "Dst":

                    connections.append({

                        "source": source,

                        "destination": p.text

                    })

    return connections