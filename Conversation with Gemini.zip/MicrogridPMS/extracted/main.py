import os
import json

from parser import load_xml
from parser import extract_blocks
from parser import extract_connections


SYSTEMS_FOLDER = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/20062026/MicrogridPMS/extracted/simulink/systems"

all_blocks = []

all_connections = []


for file in os.listdir(SYSTEMS_FOLDER):

    if not file.endswith(".xml"):

        continue

    xml_path = os.path.join(
        SYSTEMS_FOLDER,
        file
    )

    root = load_xml(xml_path)

    blocks = extract_blocks(root)

    conns = extract_connections(root)

    all_blocks.extend(blocks)

    all_connections.extend(conns)


result = {

    "blocks": all_blocks,

    "connections": all_connections

}


os.makedirs("output", exist_ok=True)

with open(
    "output/knowledge_graph.json",
    "w",
    encoding="utf-8"
) as f:

    json.dump(
        result,
        f,
        indent=2
    )


print("Done")
print("Blocks:", len(all_blocks))
print("Connections:", len(all_connections))