import pandas as pd
import networkx as nx
import zipfile
import xml.etree.ElementTree as ET
import json
import os
from networkx.readwrite import json_graph

# =========================================================
# SET YOUR ABSOLUTE DIRECTORY PATH HERE
# =========================================================
BASE_DIR = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Test_Gemini"

# =========================================================
# INITIALIZE THE MASTER GRAPH
# =========================================================
G = nx.DiGraph()

# =========================================================
# STEP 1: PARSE EXCEL & GET MODEL NAMES
# =========================================================
print(f"--- STEP 1: EXCEL (SPEC) PARSING FROM {BASE_DIR} ---")
try:
    excel_path = os.path.join(BASE_DIR, 'signal_spec.xlsx')
    
    if not os.path.exists(excel_path):
        print(f"-> [ERROR] Excel file dorakaledu! Ee path lo check cheyandi: {excel_path}")
        exit()
        
    df = pd.read_excel(excel_path, engine='openpyxl')
    
    # Clean formatting
    df['Type'] = df['Type'].astype(str).str.strip().str.lower()
    df['Function'] = df['Function'].astype(str).str.strip()
    df['signal'] = df['signal'].astype(str).str.strip()

    # Build Base Nodes and Edges
    for index, row in df.iterrows():
        model_node = row['Function']
        signal_node = row['signal']
        
        G.add_node(model_node, type='Model', system=str(row.get('System', 'Unknown')))
        clean_states = str(row.get('Values', '')).replace('\n', ' ')
        G.add_node(signal_node, type='Signal', domain=str(row.get('Characteristics', '')), states=clean_states)
        
        if row['Type'] == 'output':
            G.add_edge(model_node, signal_node, relationship='GENERATES')
        elif row['Type'] == 'input':
            G.add_edge(signal_node, model_node, relationship='CONSUMES')

    unique_models = df['Function'].unique()
    print(f"-> Excel Parsing Success! Found {len(unique_models)} Models: {list(unique_models)}\n")

except Exception as e:
    print(f"-> [ERROR] Excel read failed: {e}")
    exit()

# =========================================================
# STEP 2: STATEFLOW PARSER FUNCTION
# =========================================================
def parse_stateflow_logic(file_path, model_name, graph):
    try:
        with zipfile.ZipFile(file_path, 'r') as archive:
            xml_files = [f for f in archive.namelist() if 'stateflow.xml' in f.lower() or 'blockdiagram.xml' in f.lower()]
            
            if not xml_files:
                return False
                
            with archive.open(xml_files[0]) as xml_file:
                tree = ET.parse(xml_file)
                root = tree.getroot()
                
                state_id_map = {}
                
                # Extract States
                for state in root.iter('state'):
                    state_id = state.get('SSID') if state.get('SSID') else state.get('id')
                    state_name = state.get('name')
                    
                    if not state_name:
                        name_tag = state.find('.//P[@Name="name"]')
                        if name_tag is not None:
                            state_name = name_tag.text
                            
                    if state_id and state_name:
                        clean_name = state_name.strip()
                        state_node_name = f"{model_name}_{clean_name}"
                        
                        state_id_map[state_id] = state_node_name
                        graph.add_node(state_node_name, type='State', parent_model=model_name)
                        graph.add_edge(model_name, state_node_name, relationship='CONTAINS')

                # Extract Transitions
                for transition in root.iter('transition'):
                    src_tag = transition.find('.//src/id')
                    dst_tag = transition.find('.//dst/id')
                    
                    if src_tag is not None and dst_tag is not None:
                        src_id = src_tag.text
                        dst_id = dst_tag.text
                        
                        if src_id in state_id_map and dst_id in state_id_map:
                            source_node = state_id_map[src_id]
                            target_node = state_id_map[dst_id]
                            graph.add_edge(source_node, target_node, relationship='TRANSITIONS_TO')
        return True
    except Exception as e:
        print(f"-> [ERROR] Failed to parse logic in {file_path}: {e}")
        return False

# =========================================================
# STEP 3: AUTOMATED BULK EXECUTION
# =========================================================
print("--- STEP 2: BULK STATEFLOW EXTRACTION ---")

for model_name in unique_models:
    # Adding the Base Directory path to the file search
    expected_slx = os.path.join(BASE_DIR, f"{model_name}.slx")
    expected_zip = os.path.join(BASE_DIR, f"{model_name}.zip")
    
    file_to_parse = None
    
    if os.path.exists(expected_slx):
        file_to_parse = expected_slx
    elif os.path.exists(expected_zip):
        file_to_parse = expected_zip
        
    if file_to_parse:
        success = parse_stateflow_logic(file_to_parse, model_name, G)
        if success:
            print(f"-> [SUCCESS] Integrated internal logic from: {os.path.basename(file_to_parse)}")
        else:
            print(f"-> [WARNING] No Stateflow/Charts found inside: {os.path.basename(file_to_parse)}")
    else:
        print(f"-> [MISSING] Could not find '{model_name}.slx' or '.zip' in the folder. Skipped.")

# =========================================================
# STEP 4: SAVE EXPORTS IN THE SAME FOLDER
# =========================================================
print("\n--- FINAL MASTER GRAPH METRICS ---")
print(f"Total Unique Nodes: {G.number_of_nodes()}")
print(f"Total Logic Edges: {G.number_of_edges()}")

json_output_path = os.path.join(BASE_DIR, "BDC_Knowledge_Graph.json")
txt_output_path = os.path.join(BASE_DIR, "BDC_System_Paths.txt")

graph_data = json_graph.node_link_data(G)
with open(json_output_path, "w", encoding='utf-8') as json_file:
    json.dump(graph_data, json_file, indent=4)

with open(txt_output_path, "w", encoding='utf-8') as text_file:
    text_file.write("=== COMPLETE BDC LOGIC PATHS ===\n\n")
    for source, target, edge_data in G.edges(data=True):
        text_file.write(f"[{source}] --({edge_data['relationship']})--> [{target}]\n")

print(f"\nAll Done! Saved outputs directly to your folder: {BASE_DIR}")