# import json
# import networkx as nx
# from networkx.readwrite import json_graph
# import os

# # Llama-cpp ని ఇంపోర్ట్ చేస్తున్నాం
# from llama_cpp import Llama

# # ==========================================
# # 1. PATHS
# # ==========================================
# BASE_DIR = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Test_Gemini"
# GRAPH_PATH = os.path.join(BASE_DIR, "BDC_Knowledge_Graph.json")

# # ఇక్కడ మీ దగ్గర ఉన్న .gguf ఫైల్ ఎగ్జాక్ట్ పాత్ ఇవ్వండి!
# GGUF_MODEL_PATH = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Phi-3.5-mini-instruct-Q5_K_S.gguf" 

# # ==========================================
# # 2. LOAD GRAPH
# # ==========================================
# print("Loading BDC Knowledge Graph...")
# try:
#     with open(GRAPH_PATH, "r", encoding='utf-8') as f:
#         data = json.load(f)
#     G = json_graph.node_link_graph(data)
# except Exception as e:
#     print(f"Error loading graph: {e}")
#     exit()

# # ==========================================
# # 3. LOAD LOCAL LLM (llama-cpp-python)
# # ==========================================
# print("Loading Local GGUF Model... (Idi konchem time teeskovachu)")
# try:
#     # n_gpu_layers=-1 పెడితే మీ దగ్గర ఉన్న CUDA ని ఆటోమేటిక్ గా వాడుకుంటుంది
#     llm = Llama(
#         model_path=GGUF_MODEL_PATH,
#         n_ctx=2048,           # Context window (గ్రాఫ్ లాజిక్ సరిపోయేంత)
#         n_gpu_layers=-1,      # GPU acceleration కోసం 
#         verbose=False         # కన్సోల్ లో ఎక్స్ట్రా లాగ్స్ రాకుండా
#     )
# except Exception as e:
#     print(f"Model Load Error: {e}")
#     exit()

# # ==========================================
# # 4. LOGIC TRACING (Graph RAG)
# # ==========================================
# def trace_signal(target_node):
#     if target_node not in G:
#         return f"Error: '{target_node}' not found in the graph."
        
#     ancestors = nx.ancestors(G, target_node)
#     relevant_nodes = ancestors.union({target_node})
#     subgraph = G.subgraph(relevant_nodes)
    
#     trace_text = "Exact System Logic Path:\n"
#     for u, v, edge_data in subgraph.edges(data=True):
#         trace_text += f"[{u}] --({edge_data.get('relationship')})--> [{v}]\n"
        
#     return trace_text

# # ==========================================
# # 5. AI INFERENCE (Generate Answer)
# # ==========================================
# def ask_llama_cpp(question, logic_context):
#     system_prompt = (
#         "You are an offline Automotive BDC logic expert. "
#         "Read the provided 'Exact System Logic Path' and explain how the target signal is generated step-by-step. "
#         "DO NOT guess. DO NOT add outside information. Only translate the provided nodes and edges."
#     )
    
#     # Llama-cpp Chat Completion format
#     response = llm.create_chat_completion(
#         messages=[
#             {"role": "system", "content": system_prompt},
#             {"role": "user", "content": f"Context:\n{logic_context}\n\nUser Question: {question}"}
#         ],
#         temperature=0.1,  # Strict facts only
#         max_tokens=500
#     )
    
#     return response["choices"][0]["message"]["content"]

# # ==========================================
# # 6. EXECUTE QUERY
# # ==========================================
# target_signal = "s_doorwarning" 

# print(f"\n--- Tracing Logic for '{target_signal}' ---")
# extracted_logic = trace_signal(target_signal)
# print(extracted_logic)

# print("\n--- Generating Explanation using llama-cpp-python ---")
# user_question = f"Based on the logic path, explain exactly how {target_signal} is generated. What models and states are involved?"

# ai_answer = ask_llama_cpp(user_question, extracted_logic)

# print("\n=== AI EXPLANATION ===\n")
# print(ai_answer)
# print("\n======================")


import tkinter as tk
from tkinter import scrolledtext
import threading
import os
import json
import networkx as nx
from networkx.readwrite import json_graph
from llama_cpp import Llama

# ==========================================
# 0. STRICT OFFLINE ENVIRONMENT LOCK
# ==========================================
# ఎటువంటి టెలిమెట్రీ లేదా ఇంటర్నెట్ కనెక్షన్ కి ట్రై చేయకుండా లాక్ చేస్తున్నాం
os.environ["HF_HUB_OFFLINE"] = "1" 
os.environ["HUGGINGFACE_HUB_DISABLE_TELEMETRY"] = "1"
os.environ["OMP_NUM_THREADS"] = "4" # CPU పెర్ఫార్మన్స్ కోసం

# ==========================================
# 1. PATHS (నీ ఫోల్డర్ పాతే ఇక్కడ ఉంచాను)
# ==========================================
BASE_DIR = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Test_Gemini"
GRAPH_PATH = os.path.join(BASE_DIR, "BDC_Knowledge_Graph.json")
GGUF_MODEL_PATH = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Phi-3.5-mini-instruct-Q5_K_S.gguf" # <-- ఇక్కడ నీ GGUF పాత్ ఇవ్వు

# ==========================================
# 2. LOAD KNOWLEDGE GRAPH
# ==========================================
try:
    with open(GRAPH_PATH, "r", encoding='utf-8') as f:
        data = json.load(f)
    G = json_graph.node_link_graph(data)
    print("Graph Loaded Successfully!")
except Exception as e:
    print(f"Graph Error: {e}")
    G = nx.DiGraph() # ఫెయిల్ అయితే ఎంప్టీ గ్రాఫ్

# ==========================================
# 3. LOAD LLM (llama-cpp-python)
# ==========================================
print("Loading Local GGUF Model into RAM...")
try:
    llm = Llama(
        model_path=GGUF_MODEL_PATH,
        n_ctx=4096,           # పెద్ద కంటెక్స్ట్ విండో (TCs కోసం)
        n_gpu_layers=-1,      
        verbose=False         
    )
    print("Model Ready!")
except Exception as e:
    print(f"Model Load Error: {e}")
    exit()

# ==========================================
# 4. GUI & CHAT LOGIC (Tkinter)
# ==========================================
class BDC_Assistant_App:
    def __init__(self, root):
        self.root = root
        self.root.title("BDC Offline Logic Assistant (Strict Mode)")
        self.root.geometry("800x600")
        self.root.configure(bg="#1e1e1e") # Dark Theme
        
        # చాట్ హిస్టరీ సేవ్ చేసుకోవడానికి (Step-by-step మెమరీ)
        self.chat_history = [
            {"role": "system", "content": "You are a strictly offline Automotive BDC Engineer. Use the provided Knowledge Graph exact paths to answer. If asked for Test Cases (TC), generate Given/When/Then based on the active path."}
        ]

        # --- UI Elements ---
        self.chat_display = scrolledtext.ScrolledText(root, wrap=tk.WORD, font=("Consolas", 11), bg="#2d2d2d", fg="#ffffff")
        self.chat_display.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        self.chat_display.config(state=tk.DISABLED)
        
        input_frame = tk.Frame(root, bg="#1e1e1e")
        input_frame.pack(padx=10, pady=(0, 10), fill=tk.X)
        
        self.msg_entry = tk.Entry(input_frame, font=("Arial", 12), bg="#3d3d3d", fg="#ffffff", insertbackground="white")
        self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10), ipady=5)
        self.msg_entry.bind("<Return>", self.handle_send)
        
        self.send_btn = tk.Button(input_frame, text="Send Query", font=("Arial", 10, "bold"), bg="#007acc", fg="white", command=self.handle_send)
        self.send_btn.pack(side=tk.RIGHT, ipadx=10, ipady=3)
        
        self.append_to_chat("System", "BDC Brain is Online. No internet detected. Type a signal name or ask a question.", "#00ff00")

    def append_to_chat(self, sender, message, color):
        self.chat_display.config(state=tk.NORMAL)
        self.chat_display.insert(tk.END, f"{sender}: ", ("sender_style",))
        self.chat_display.insert(tk.END, f"{message}\n\n", ("msg_style",))
        
        # Colors
        self.chat_display.tag_config("sender_style", foreground=color, font=("Consolas", 11, "bold"))
        self.chat_display.tag_config("msg_style", foreground="#ffffff")
        
        self.chat_display.see(tk.END)
        self.chat_display.config(state=tk.DISABLED)

    # గ్రాఫ్ ని ఆటోమాటిక్ గా స్కాన్ చేసి లాజిక్ లాగే ఫంక్షన్
    def extract_graph_context(self, user_text):
        context = ""
        # యూజర్ టైప్ చేసిన మెసేజ్ లో ఏదైనా నోడ్ (సిగ్నల్/మోడల్) పేరు ఉందేమో వెతుకుతుంది
        for node in G.nodes():
            if node in user_text:
                ancestors = nx.ancestors(G, node)
                subgraph = G.subgraph(ancestors.union({node}))
                context += f"\nGraph Logic for {node}:\n"
                for u, v, edge_data in subgraph.edges(data=True):
                    context += f"[{u}] --({edge_data.get('relationship')})--> [{v}]\n"
        return context

    def handle_send(self, event=None):
        user_msg = self.msg_entry.get().strip()
        if not user_msg:
            return
            
        self.msg_entry.delete(0, tk.END)
        self.append_to_chat("You", user_msg, "#00bfff")
        
        # Button disable chesthunnam AI answer iche lopu
        self.send_btn.config(state=tk.DISABLED, text="Thinking...")
        
        # GUI ఫ్రీజ్ అవ్వకుండా ఉండటానికి Thread వాడుతున్నాం
        threading.Thread(target=self.generate_ai_response, args=(user_msg,), daemon=True).start()

    def generate_ai_response(self, user_msg):
        # 1. గ్రాఫ్ లో నుంచి లాజిక్ లాగడం (ఉంటేనే)
        graph_logic = self.extract_graph_context(user_msg)
        
        # కంటెక్స్ట్ ని యాడ్ చేస్తూ, సిస్టం కి పంపే ప్రాంప్ట్
        if graph_logic:
            augmented_msg = f"User Question: {user_msg}\n\nExtracted BDC Logic (Treat as absolute truth):\n{graph_logic}"
            self.chat_history.append({"role": "user", "content": augmented_msg})
        else:
            self.chat_history.append({"role": "user", "content": user_msg})

        # 2. llama-cpp కి పంపడం (Chat Memory తో పాటు)
        try:
            response = llm.create_chat_completion(
                messages=self.chat_history,
                temperature=0.1,
                max_tokens=800
            )
            ai_reply = response["choices"][0]["message"]["content"]
            
            # AI ఇచ్చిన రిప్లై ని కూడా హిస్టరీ లో సేవ్ చేస్తున్నాం (సో దట్ ఇట్ రిమెంబర్స్)
            self.chat_history.append({"role": "assistant", "content": ai_reply})
            
            # Update GUI securely from thread
            self.root.after(0, lambda: self.append_to_chat("AI", ai_reply, "#ffaa00"))
        except Exception as e:
            self.root.after(0, lambda: self.append_to_chat("Error", str(e), "#ff0000"))
            
        # Button మళ్ళీ ఎనేబుల్ చేయడం
        self.root.after(0, lambda: self.send_btn.config(state=tk.NORMAL, text="Send Query"))

# ==========================================
# 5. RUN APP
# ==========================================
if __name__ == "__main__":
    root = tk.Tk()
    app = BDC_Assistant_App(root)
    root.mainloop()
# ==========================================
