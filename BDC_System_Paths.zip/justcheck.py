import os

BASE_DIR = r"D:/Personal/Matlab_Works/BDC_Brain/Multi_agent/17062026/Test_Gemini"

print(f"Searching in: {BASE_DIR}\n")
try:
    files = os.listdir(BASE_DIR)
    print("Files found exactly as:")
    for f in files:
        print(f" -> '{f}'")
except Exception as e:
    print(f"Path Error: {e}")